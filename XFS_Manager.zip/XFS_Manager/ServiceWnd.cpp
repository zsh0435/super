// ServiceWnd.cpp : implementation file
//

#include "stdafx.h"
#include "NI_XFSMgr.h"
#include "ServiceWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CServiceWnd

CServiceWnd::CServiceWnd()
{
	
}

CServiceWnd::~CServiceWnd()
{
}



/////////////////////////////////////////////////////////////////////////////
// CServiceWnd message handlers
